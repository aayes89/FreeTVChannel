package mx.slam.myfreedomtv.Adapters;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.List;

import mx.slam.myfreedomtv.R;
import mx.slam.myfreedomtv.Model.Channel;

public class ChannelAdapter extends RecyclerView.Adapter<ChannelAdapter.ViewHolder> {
    private List<Channel> channels;
    private Context context;
    private WebView webView; // Agrega esta variable al adaptador

    public ChannelAdapter(List<Channel> channels, Context context, WebView webView) {
        // Constructor del adaptador
        this.channels = channels;
        this.context = context;
        this.webView = webView; // Asigna el WebView pasado como parámetro
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.channel_layout, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Log.d("POS", "Position on list: "+position);
        Channel channel = channels.get(position);
        holder.nameTextView.setText(channel.getName());
        holder.descriptionTextView.setText(channel.getDescription());
        Picasso.get().load(channel.getIcon()).into(holder.icon);

        holder.itemView.setOnClickListener(v -> {
            webView.setVisibility(View.VISIBLE);
            webView.loadUrl(channel.getUrl());
        });
    }

    @Override
    public int getItemCount() {
        return channels.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView nameTextView, descriptionTextView;
        ImageView icon;

        public ViewHolder(View itemView) {
            super(itemView);
            nameTextView = itemView.findViewById(R.id.nameTextView);
            descriptionTextView = itemView.findViewById(R.id.descriptionTextView);
            icon = itemView.findViewById(R.id.idIVIcon);
        }
    }
}

