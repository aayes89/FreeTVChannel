package mx.slam.myfreedomtv;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import java.util.List;

import mx.slam.myfreedomtv.Adapters.ChannelAdapter;
import mx.slam.myfreedomtv.Interfaces.APIService;
import mx.slam.myfreedomtv.Model.Channel;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
        private RecyclerView recyclerView;
        private ChannelAdapter adapter;
        private Context context;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);

            recyclerView = findViewById(R.id.recyclerView);
            recyclerView.setLayoutManager(new LinearLayoutManager(this));

            APIService apiService = RetrofitClient.getRetrofitInstance().create(APIService.class);
            Call<List<Channel>> call = apiService.getChannels();

            call.enqueue(new Callback<List<Channel>>() {
                @Override
                public void onResponse(Call<List<Channel>> call, Response<List<Channel>> response) {
                    if (response.isSuccessful()) {
                        List<Channel> channels = response.body();
                        adapter = new ChannelAdapter(channels,context);
                        recyclerView.setAdapter(adapter);
                    } else {
                        Log.e("ERROR","Problem fetching data from API");
                    }
                }

                @Override
                public void onFailure(Call<List<Channel>> call, Throwable t) {
                    Log.e("ERROR", t.getMessage(), t);
                }
            });
        }

        // Método para obtener un canal específico por su ID
        private void getSingleChannel(int channelId) {
            APIService apiService = RetrofitClient.getRetrofitInstance().create(APIService.class);
            Call<Channel> singleChannelCall = apiService.getChannelById(channelId);

            singleChannelCall.enqueue(new Callback<Channel>() {
                @Override
                public void onResponse(Call<Channel> call, Response<Channel> response) {
                    if (response.isSuccessful()) {
                        Channel channel = response.body();
                        Toast.makeText(context,channel.toString(),Toast.LENGTH_LONG).show();;

                    } else {

                        Log.e("ERROR","Error fetching data channel from API");
                    }
                }

                @Override
                public void onFailure(Call<Channel> call, Throwable t) {
                    Log.e("ERROR",t.getMessage(),t);
                }
            });
        }
    }
