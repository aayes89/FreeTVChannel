package mx.slam.myfreedomtv;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.util.List;

import mx.slam.myfreedomtv.Adapters.ChannelAdapter;
import mx.slam.myfreedomtv.Interfaces.APIService;
import mx.slam.myfreedomtv.Model.Channel;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
        private RecyclerView recyclerView;
        private ChannelAdapter adapter;

        private WebView webView;
        private Context context;
        private int count;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);
            count = 0;
            context = this;
            recyclerView = findViewById(R.id.recyclerView);
            recyclerView.setLayoutManager(new LinearLayoutManager(context));

            webView = findViewById(R.id.webView);
            webView.setWebViewClient(new WebViewClient());
            webView.getSettings().setJavaScriptEnabled(true);
            webView.setVisibility(View.GONE);

            APIService apiService = RetrofitClient.getRetrofitInstance().create(APIService.class);
            Call<List<Channel>> call = apiService.getChannels();

            call.enqueue(new Callback<List<Channel>>() {
                @Override
                public void onResponse(Call<List<Channel>> call, Response<List<Channel>> response) {
                    if (response.isSuccessful()) {
                        List<Channel> channels = response.body();
                        adapter = new ChannelAdapter(channels,context,webView);
                        recyclerView.setAdapter(adapter);
                    } else {
                        Log.e("ERROR onResponse", "Error fetching data channel from API");
                        Toast.makeText(context, "Error fetching channel data.", Toast.LENGTH_LONG).show();
                    }
                }

                @Override
                public void onFailure(Call<List<Channel>> call, Throwable t) {
                    Log.e("ERROR on Failure", t.getMessage(), t);
                    Toast.makeText(context, "Error fetching data. Please check your network connection.", Toast.LENGTH_LONG).show();
                }
            });
        }

        // Método para obtener un canal específico por su ID
        private void getSingleChannel(int channelId) {
            APIService apiService = RetrofitClient.getRetrofitInstance().create(APIService.class);
            Call<Channel> singleChannelCall = apiService.getChannelById(channelId);

            singleChannelCall.enqueue(new Callback<Channel>() {
                @Override
                public void onResponse(Call<Channel> call, Response<Channel> response) {
                    if (response.isSuccessful()) {
                        Channel channel = response.body();
                        Toast.makeText(context,channel.toString(),Toast.LENGTH_LONG).show();;

                    } else {

                        Log.e("ERROR onResponse SChannel","Error fetching data channel from API");
                    }
                }

                @Override
                public void onFailure(Call<Channel> call, Throwable t) {
                    Log.e("ERROR onFailure SChannel",t.getMessage(),t);
                }
            });
        }
    @Override
    public void onBackPressed() {
        if (webView.getVisibility() == View.VISIBLE) {
            count = 0;
            webView.setVisibility(View.GONE);
        } else {
            count++;
            Toast.makeText(context, "Press again to exit", Toast.LENGTH_LONG).show();
            if(count>1)
                super.onBackPressed();
        }
    }
}