package mx.slam.myfreedomtv.Interfaces;

import java.util.List;

import mx.slam.myfreedomtv.Model.Channel;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface APIService {
    @GET("channels")
    Call<List<Channel>> getChannels();

    @GET("channel")
    Call<Channel> getChannelById(@Query("id") int channelId);
}
